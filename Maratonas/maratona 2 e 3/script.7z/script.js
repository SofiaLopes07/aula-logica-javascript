
//Maratona 2
//Verificação de maioridade
let idade = 17;
 
switch(idade){
    case 18:
        console.log("O usuário é maior de idade.");
        break;
        case 17:
            console.log("O usuário é menor de idade.");
            break;
            default:
}

//Cálculo de Salário com Aumento
let Salario = 7500;
let aumendoSalario;
if (Salario <= 2000){
    aumentoSalario = Salario * 1.10;
} else if (Salario <= 5000) {
    aumentoSalario = Salario * 1.07;
} else {
    aumentoSalario = Salario * 1.05;
}
console.log("Novo salário: R$" + aumentoSalario);

//Classificação de temperatura
let temperatura = 21;

if(temperatura <15){
    console.log("Frio");
} else if (temperatura >= 15 && temperatura <= 25){
    console.log("Agradável");
} else if (temperatura >= 26 && temperatura <= 35){
    console.log("Quente");
} else{
    console.log("Muito Quente")
}

//Maratona 3
//foreach
const tarefas = ["Fazer a cama", "Lavar a louça", "Varer a casa", "Lavar a roupa suja"];

function mostrarTarefas(tarefas, indice){
    console.log(`Índice ${indice}:${tarefas}`);
}

tarefas.forEach(mostrarTarefas);

//while (enquanto)
let m = 25;
while (m >= 1){
    console.log(m);
    m--;
}
//for
for(i = 0; i <= 5; i++){
    console.log(i);
}

let x = 5;
for(x; x > 2; x--){
    console.log(x);
}
